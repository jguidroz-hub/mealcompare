const STF_OVERLAY_ID = "skipthefee-overlay";
const STF_SHOWN_KEY = "stf_shown_restaurants";
const API_BASE = "https://skipthefee.app";
function detectPlatform() {
  const host = window.location.hostname;
  if (host.includes("doordash.com")) return "doordash";
  if (host.includes("ubereats.com")) return "ubereats";
  if (host.includes("grubhub.com")) return "grubhub";
  return null;
}
function extractRestaurantName() {
  const platform = detectPlatform();
  if (!platform) return null;
  let name = null;
  if (platform === "doordash") {
    const el = document.querySelector('[data-testid="StoreHeader"] h1, h1[class*="StoreHeader"], .store-header h1');
    name = el?.textContent?.trim() || null;
    if (!name) {
      const titleMatch = document.title.match(/^(.+?)\s*[-–|]\s*(?:Delivery|DoorDash)/i);
      if (titleMatch) name = titleMatch[1].trim();
    }
  }
  if (platform === "ubereats") {
    const el = document.querySelector('h1[data-testid="store-title-summary"], h1[class*="StoreName"]');
    name = el?.textContent?.trim() || null;
    if (!name) {
      const titleMatch = document.title.match(/^(.+?)\s*[-–|]\s*(?:Delivery|Uber\s*Eats)/i);
      if (titleMatch) name = titleMatch[1].trim();
    }
  }
  if (platform === "grubhub") {
    const el = document.querySelector('h1.restaurant-name, h1[class*="restaurantName"]');
    name = el?.textContent?.trim() || null;
    if (!name) {
      const titleMatch = document.title.match(/^(.+?)\s*[-–|]\s*(?:Delivery|Order|Grubhub)/i);
      if (titleMatch) name = titleMatch[1].trim();
    }
  }
  return name;
}
function wasRecentlyShown(restaurantName) {
  try {
    const shown = JSON.parse(localStorage.getItem(STF_SHOWN_KEY) || "{}");
    const lastShown = shown[restaurantName.toLowerCase()];
    if (!lastShown) return false;
    return Date.now() - lastShown < 24 * 60 * 60 * 1e3;
  } catch {
    return false;
  }
}
function markShown(restaurantName) {
  try {
    const shown = JSON.parse(localStorage.getItem(STF_SHOWN_KEY) || "{}");
    shown[restaurantName.toLowerCase()] = Date.now();
    const entries = Object.entries(shown).sort(([, a], [, b]) => b - a).slice(0, 50);
    localStorage.setItem(STF_SHOWN_KEY, JSON.stringify(Object.fromEntries(entries)));
  } catch {
  }
}
async function findDirectOrdering(restaurantName) {
  const metro = localStorage.getItem("stf_metro") || "nyc";
  try {
    const res = await fetch(`${API_BASE}/api/restaurants?metro=${metro}&limit=1000`);
    const data = await res.json();
    const normalizedSearch = restaurantName.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
    for (const r of data.restaurants) {
      if (!r.directUrl) continue;
      const normalizedName = r.name.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
      if (normalizedName === normalizedSearch) {
        return {
          name: r.name,
          directUrl: r.directUrl,
          platform: r.hasToast ? "Toast" : r.hasSquare ? "Square" : "Direct",
          category: r.category
        };
      }
    }
    for (const r of data.restaurants) {
      if (!r.directUrl) continue;
      const normalizedName = r.name.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
      if (normalizedName.includes(normalizedSearch) || normalizedSearch.includes(normalizedName)) {
        if (Math.min(normalizedName.length, normalizedSearch.length) >= 4) {
          return {
            name: r.name,
            directUrl: r.directUrl,
            platform: r.hasToast ? "Toast" : r.hasSquare ? "Square" : "Direct",
            category: r.category
          };
        }
      }
    }
    return null;
  } catch {
    return null;
  }
}
function showOverlay(match, deliveryPlatform) {
  if (document.getElementById(STF_OVERLAY_ID)) return;
  const platformNames = {
    doordash: "DoorDash",
    ubereats: "Uber Eats",
    grubhub: "Grubhub"
  };
  const overlay = document.createElement("div");
  overlay.id = STF_OVERLAY_ID;
  overlay.innerHTML = `
    <div style="
      position: fixed; bottom: 24px; right: 24px; z-index: 2147483647;
      width: 360px; background: #0f1729; border: 1px solid rgba(16,185,129,0.3);
      border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.5);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color: #e2e8f0; overflow: hidden;
      animation: stf-slide-in 0.3s ease-out;
    ">
      <!-- Header -->
      <div style="padding: 16px 20px 12px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.05);">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 20px;">💰</span>
          <span style="font-weight: 800; font-size: 14px; letter-spacing: -0.02em;">SkipTheFee</span>
        </div>
        <button id="stf-close" style="background: none; border: none; color: #475569; cursor: pointer; font-size: 18px; padding: 0; line-height: 1;">✕</button>
      </div>

      <!-- Body -->
      <div style="padding: 16px 20px;">
        <div style="font-size: 15px; font-weight: 700; margin-bottom: 8px; line-height: 1.4;">
          🏪 <strong>${match.name}</strong> has direct ordering
        </div>
        <div style="font-size: 13px; color: #94a3b8; line-height: 1.6; margin-bottom: 16px;">
          Skip ${platformNames[deliveryPlatform] || "delivery app"} fees — order directly through <strong style="color: #10b981;">${match.platform}</strong>. Same food, typically lower cost.
        </div>

        <!-- CTA -->
        <a href="${match.directUrl}" target="_blank" rel="noopener" id="stf-order-btn" style="
          display: block; text-align: center; padding: 14px 20px;
          background: linear-gradient(135deg, #059669, #10b981);
          color: white; font-weight: 800; font-size: 15px;
          border-radius: 12px; text-decoration: none;
          transition: opacity 0.15s;
        ">
          Order Direct from ${match.platform} →
        </a>

        <div style="text-align: center; margin-top: 10px; font-size: 11px; color: #475569;">
          Free & private · <a href="https://skipthefee.app" target="_blank" style="color: #10b981; text-decoration: none;">skipthefee.app</a>
        </div>
      </div>
    </div>

    <style>
      @keyframes stf-slide-in {
        from { transform: translateY(20px) translateX(20px); opacity: 0; }
        to { transform: translateY(0) translateX(0); opacity: 1; }
      }
    </style>
  `;
  document.body.appendChild(overlay);
  document.getElementById("stf-close")?.addEventListener("click", () => {
    overlay.style.transition = "opacity 0.2s, transform 0.2s";
    overlay.style.opacity = "0";
    overlay.style.transform = "translateY(10px)";
    setTimeout(() => overlay.remove(), 200);
  });
  document.getElementById("stf-order-btn")?.addEventListener("click", () => {
    fetch(`${API_BASE}/api/track`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        restaurant: match.name,
        slug: match.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        metro: localStorage.getItem("stf_metro") || "unknown",
        source: "extension_overlay",
        directUrl: match.directUrl,
        interceptedFrom: deliveryPlatform
      })
    }).catch(() => {
    });
  });
  setTimeout(() => {
    const el = document.getElementById(STF_OVERLAY_ID);
    if (el) {
      el.style.transition = "opacity 0.5s";
      el.style.opacity = "0";
      setTimeout(() => el.remove(), 500);
    }
  }, 15e3);
}
let lastDetectedName = "";
async function detectAndShow() {
  const platform = detectPlatform();
  if (!platform) return;
  const restaurantName = extractRestaurantName();
  if (!restaurantName || restaurantName === lastDetectedName) return;
  lastDetectedName = restaurantName;
  if (wasRecentlyShown(restaurantName)) return;
  const match = await findDirectOrdering(restaurantName);
  if (!match) return;
  markShown(restaurantName);
  showOverlay(match, platform);
}
let lastUrl = window.location.href;
const urlObserver = new MutationObserver(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href;
    document.getElementById(STF_OVERLAY_ID)?.remove();
    lastDetectedName = "";
    setTimeout(detectAndShow, 1500);
  }
});
urlObserver.observe(document.body, { childList: true, subtree: true });
setTimeout(detectAndShow, 2e3);
console.log("[SkipTheFee] Overlay content script loaded");
