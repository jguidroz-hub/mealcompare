function normalizeMenuItemName(name) {
  return name.toLowerCase().replace(/[®™©]/g, "").replace(/\s*\(.*?\)\s*/g, "").replace(/\s*-\s*delivered\s*/gi, "").replace(/\s*\[.*?\]\s*/g, "").replace(/#(\d+)\s+/g, "#$1 ").replace(/\s*-\s*/g, " ").replace(/[^a-z0-9#\s]/g, "").replace(/\s+/g, " ").trim();
}
let lastCartHash = "";
function extractCart() {
  const restaurantEl = document.querySelector('[data-testid="StoreHeader"] h1') ?? document.querySelector('h1[class*="StoreHeader"]') ?? document.querySelector(".store-header h1");
  const restaurantName = restaurantEl?.textContent?.trim();
  if (!restaurantName) return null;
  const items = [];
  const cartSelectors = [
    '[data-testid="CartItemList"] [data-testid="CartItem"]',
    '[class*="CartItem"]',
    ".cart-item"
  ];
  let cartItems = null;
  for (const selector of cartSelectors) {
    cartItems = document.querySelectorAll(selector);
    if (cartItems.length > 0) break;
  }
  if (!cartItems || cartItems.length === 0) return null;
  for (const el of cartItems) {
    const nameEl = el.querySelector('[data-testid="CartItemName"], [class*="itemName"], .item-name');
    const priceEl = el.querySelector('[data-testid="CartItemPrice"], [class*="itemPrice"], .item-price');
    const qtyEl = el.querySelector('[data-testid="CartItemQuantity"], [class*="quantity"], .quantity');
    const name = nameEl?.textContent?.trim();
    const priceText = priceEl?.textContent?.trim();
    if (!name || !priceText) continue;
    const price = parsePriceCents(priceText);
    const quantity = parseInt(qtyEl?.textContent?.trim() ?? "1", 10) || 1;
    items.push({
      name,
      normalizedName: normalizeMenuItemName(name),
      price,
      quantity
    });
  }
  if (items.length === 0) return null;
  return {
    platform: "doordash",
    restaurantName,
    items,
    pageUrl: window.location.href
  };
}
function parsePriceCents(text) {
  const match = text.match(/\$?([\d,]+\.?\d*)/);
  if (!match) return 0;
  return Math.round(parseFloat(match[1].replace(",", "")) * 100);
}
function hashCart(detection) {
  return JSON.stringify(detection.items.map((i) => `${i.normalizedName}:${i.quantity}`));
}
function checkCart() {
  const cart = extractCart();
  if (!cart) return;
  const hash = hashCart(cart);
  if (hash === lastCartHash) return;
  lastCartHash = hash;
  chrome.runtime.sendMessage({
    type: "CART_DETECTED",
    payload: cart
  });
}
const observer = new MutationObserver(() => {
  clearTimeout(window.__mcDebounce);
  window.__mcDebounce = setTimeout(checkCart, 500);
});
observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});
setTimeout(checkCart, 2e3);
console.log("[SkipTheFee] DoorDash content script loaded");
